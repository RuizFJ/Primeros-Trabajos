package clase0322_contador2;

public class contadorletras {

	public static void main(String[] args) {
		
		//para contar letras
		
		int tamaño;
		String palabra = "hola mundo";
		tamaño = palabra.length();
		System.out.println("El numero de palabras es = "+tamaño);
	}

}
