package Triangulo;

import java.util.Scanner;

public class Triangulo {

	public static void main(String[] args) {
	
		Scanner teclado = new Scanner(System.in);
		
		int a,b,c;
		do {
		
		System.out.println("Ingrese el primer lado del triángulo");
		
		a=teclado.nextInt();
	 }    while (a<0);
		
		do {
		System.out.println("Ingrese el segundo lado del triángulo");
		b=teclado.nextInt();
		} while(b<0);
		
		do {
		System.out.println("Ingrese el tercer lado del triángulo");
		c=teclado.nextInt();
		}while(c<0);
		
		if (a==b && a==c && b==c) {
			System.out.println("El triángulo es equliatero");
		} 
		else if (a!=b && a!=c && b!=c) {
			System.out.println("El triángulo es escaleno");
			
		} else {
			System.out.println("El triángulo es isósceles");
		}
		
				

	}

}
