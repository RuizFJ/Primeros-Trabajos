package clase0322_contador2;

public class contador1 {

	public static void main(String[] args) {
		
		int count=0,acumulador=0;
		
		while(count<5){
			count=count+1;
			acumulador= acumulador+count;
			
		}
          System.out.println(acumulador);
	}

}
