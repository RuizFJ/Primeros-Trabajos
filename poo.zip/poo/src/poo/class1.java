package poo;

import java.util.Scanner;

public class class1 {
	public static void main (String []args) {
		
		
		
		Scanner tc= new Scanner(System.in);
		
		
		int a,b;
		
		System.out.println("Ingrese el primer elemento");
		a=tc.nextInt();
		System.out.println("Ingrese el segundo valor");
		b=tc.nextInt();
		
		operaciones op = new operaciones ();
		System.out.println("El resultado es "+ op.suma(a, b));
		
		System.out.println("El resultado es "+op.resta(a, b));
	}

}
