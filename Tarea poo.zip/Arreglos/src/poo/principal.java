package poo;

import java.util.Scanner;

public class principal {

	public static void main(String[] args) {
		
		Scanner tc = new Scanner(System.in);
		operaciones op = new operaciones(0, 0, 0);
		
		int n1,notas1=0;
		
		do {
		System.out.println("Cuantas notas ingresara");
		n1=tc.nextInt();
		} while (n1<=0);
		System.out.println(op.pedir(n1, notas1));
		
		
		
		
		
		

	}

}
