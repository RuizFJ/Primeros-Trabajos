package clase0322_contador;

public class contador {

	public static void main(String[] args) {
		
		int count = 0,contador;
		
		while(count <6) {
			
			count=count+1;
			System.out.println(count);
		}

	}

}
