package Par;

import java.util.Scanner;

public class Par {

	public static void main(String[] args) {
		Scanner teclado= new Scanner(System.in);
		
		int a;
		
			System.out.println("Ingrese el valor");
			a=teclado.nextInt();
			if (a%2==0) {
				System.out.println("El número ingresado es par");
			} else {
				System.out.println("El número ingresado es impar");
			}
		

	}

}
