package pooclase;

public class mainhere {

	public static void main(String[] args) {
		
		alumno al = new alumno("Juan","Robles","Nic","12");
		
		
		al.setMatricula("123");
		al.mostrardatos();
		
		
		

	}

}
