package poo;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class operaciones {
	
	int num,notas;

	public operaciones(int num, int notas, int most) {
		this.num = num;
		this.notas = notas;
		
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public int getNotas() {
		return notas;
	}

	public void setNotas(int notas) {
		this.notas = notas;
	}
	
	
	public float pedir (int n, int notas) {
		Scanner tc = new Scanner (System.in);
		int suma=0;
		float prom=0;
		for (int i=1;i<=n;i++) {
			do {
			System.out.println("Ingrese el numero "+i);
			notas=tc.nextInt();
			} while (notas<0);
			suma +=notas;
			prom=suma/n;
		}
			
		
		return (float) prom;
	}
	
	
	
	

}
