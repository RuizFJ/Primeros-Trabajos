package poo;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		
		
		Racional op = new Racional(0, 0, 0, 0);
		
		
		Scanner tc = new Scanner(System.in);
		
		op.leer();
		
		op.multi();
		op.divi();
		op.suma();
		op.resta();
		
		
	}

}
