package pooclase;

import javax.swing.JOptionPane;

public class alumno extends personas {
	
	public String matricula;
	
	

	public alumno(String nombre, String apellido, String nacionalidad, String matricula,String edad) {
		super(nombre, apellido, nacionalidad,edad);
		this.matricula = matricula;
	}
	



	public String getMatricula() {
		return matricula;
	}




	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}




	public alumno(String nombre, String apellido, String nacionalidad,String edad) {
		super(nombre, apellido, nacionalidad,edad);
		
	}
	
	public void  mostrardatos () {
		JOptionPane.showMessageDialog(null,"alumno:\n"+getNombre()+"\n"+getApellido()+"\n"+getNacionalidad()+"\n"+getMatricula()+"\n"+getEdad() );
	}

}
