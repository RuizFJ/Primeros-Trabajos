package Calculadora;

import java.util.Scanner;

public class Calculadora {

	public static void main(String[] args) {
		
		Scanner tc = new Scanner(System.in);
		
		float a,b;
		int opcion=0,f ;
		float suma=0,d;
		
		try {
		do {
			System.out.println("Ingrese \n 1 para sumar \n 2 para restar \n 3 para multiplicar \n 4 para dividir \n 5 para raiz cuadrada \n 6 para elevar a una potencia");
			opcion=tc.nextInt();
			
		}
		while (opcion<0);
		
		switch (opcion) {
		
		case 1:
			System.out.println("Ingrese el primer valor");
			a=tc.nextInt();
			System.out.println("Ingrese el segundo valor");
			b=tc.nextFloat();
			suma = a+b;
			System.out.println("La suma es = "+suma);
			break;		
					
		case 2:
			System.out.println("Ingrese el primer valor");
		a=tc.nextFloat();
		System.out.println("Ingrese el segundo valor");
		b=tc.nextFloat();
		suma = a-b;
		System.out.println("La resta es = "+suma);
		break;
		case 3:
			System.out.println("Ingrese el primer valor");
			a=tc.nextFloat();
			System.out.println("Ingrese el segundo valor");
			b=tc.nextFloat();
			suma = a*b;
			System.out.println("La multiplicacion es = "+suma);
			break;
		case 4:
			try {
			System.out.println("Ingrese el primer valor");
			a=tc.nextFloat();
			System.out.println("Ingrese el segundo valor");
			b=tc.nextFloat();
			suma = a/b;
			System.out.println("La division es = "+suma);
			} catch (java.lang.ArithmeticException aa) {
				System.out.println("La division entre cero no existe");
				
			}
			break;
			
		case 5:
			System.out.println("Ingrese el valor que dese sacar raiz cuadrada");
			d=tc.nextFloat();
					System.out.println("La raiz es = "+ Math.sqrt(d));
					break;
			
		case 6:
			System.out.println("Ingrese el valor que dese elevar");
			a=tc.nextFloat();
			do {
				System.out.println("Ingrese el exponente");
				f=tc.nextInt();
			}while (f<0);
			
			System.out.println("El numero elevado es = " + Math.pow(a, f));
			
			break;
			default:
				System.out.println("Opcion no valida");
			
		} 
		}
		catch (java.util.InputMismatchException ww) {
		System.out.println("Opcion no valida");
		} 
		
		}
		
	
		
		
	}


