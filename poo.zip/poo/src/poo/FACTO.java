package poo;

import java.util.Scanner;

public class FACTO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc = new Scanner(System.in);
		
		int n,suma = 1;
		
		System.out.println("Ingrese el numero del facto");
		n=tc.nextInt();
		
		for (int i=1;i<=n;i++) {
			suma=suma*i;
		}
		
		System.out.println(suma);
		
		
		
		
		
	}

}
