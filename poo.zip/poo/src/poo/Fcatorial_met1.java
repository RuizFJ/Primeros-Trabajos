package poo;

public class Fcatorial_met1 {

	int facto;
	int facto2=1;

	
	
	
	
	
	
	
	


	public int getFacto2() {
		return facto2;
	}




	public void setFacto2(int facto2) {
		this.facto2 = facto2;
	}




	public Fcatorial_met1(int facto, int facto2) {
		this.facto = facto;
		this.facto2 = facto2;
	}









	public int getFacto() {
		return facto;
	}




	public void setFacto(int facto) {
		this.facto = facto;
	}




	public static int factorial (int facto2) {
	int facto1 = 1;
		for (int i=1;i<=facto2;i++) {
		 facto1 = facto1*i;
		}
		return facto1;
		
	}
	
	
	
	
	
	
	
	
	
	
	
}
