package poo;

import java.util.Scanner;

public class Facto_mostr {

	public static void main(String[] args) {
		
		Scanner tc = new Scanner(System.in);
		Fcatorial_met1 op = new Fcatorial_met1(0, 0);
		int n;
		
		System.out.println("Ingrese el numero que desea sacar factorial");
		n=tc.nextInt();
		
		System.out.println(op.factorial(n));
		
		

	}

}
