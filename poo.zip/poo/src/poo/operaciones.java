package poo;

public class operaciones {

	int num1; //atributos
	int num2;
	
	

	public operaciones() {
		this.num1 = num1;
		this.num2 = num2;
	}



	public int getNum1() {
		return num1;
	}



	public void setNum1(int num1) {
		this.num1 = num1;
	}



	public int getNum2() {
		return num2;
	}



	public void setNum2(int num2) {
		this.num2 = num2;
	}
	
	
	
	// metodos propios 
	
	
	
	public static int suma (int num1, int num2) {
		int suma;
		 suma=num1+num2;
		 return suma;
	}
	

	public static int resta (int num1, int num2) {
		int resta;
		 resta=num1-num2;
		 return resta;
	}
	
	
	public void mostrar_mensaje() {
		System.out.println("Saliendo");
	}
	
	
	
	
	
	
	
}	
	

