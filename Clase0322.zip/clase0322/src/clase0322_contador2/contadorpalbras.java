package clase0322_contador2;

import java.util.Scanner;
import java.util.StringTokenizer;

public class contadorpalbras {

	public static void main(String[] args) {
		Scanner tc=new Scanner(System.in);
		
		String palabra;
		System.out.println("Ingrese una palabra");
		palabra=tc.nextLine();
		StringTokenizer st = new StringTokenizer(palabra);
		System.out.println("Numero de la palabra es = "+st.countTokens());
//para saber cuantas palabras hay
	}

}
