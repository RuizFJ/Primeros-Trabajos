package clase0322;

import java.util.Scanner;
  

public class main {
	 public static void clear() {
		  for(int i=1;i<=20;i++) {
			  System.out.println("");
		  }
		
	}

	public static void main(String[] args) {
		
		Scanner tc= new Scanner(System.in);
		int op;
		boolean exit=false;
		
		while (!exit) {
			
			System.out.println("1. opciòn compras");
			System.out.println("2. opciòn ventas");
			System.out.println("3. opciòn catalogos");
			System.out.println("Ingrese una opciòn");
			op=tc.nextInt();
			clear();
			switch (op) {
			
			case 1:
				System.out.println("*******************************");
				System.out.println("Ha ingresado al menu de compras");
				System.out.println("*******************************");
				clear();
				break;
				
			case 2: 
				System.out.println("*******************************");
				System.out.println("Ha ingresado al menu de ventas");
				System.out.println("*******************************");
				clear();
			break;
			
			case 3: 
				System.out.println("*******************************");
				System.out.println("Ha ingresado al menu de catalogos");
				System.out.println("*******************************");
				clear();
			case 4:
				exit= true;
				System.out.println("Adios");
			
			break;
			}
			
			
		}
		
		
		

	}

}
